<x-layout judul="home">
    <div class="container mt-4">
        
        <h2 class="text-center mb-4">Selamat datang di website pencatatan todo list</h2>
        <h2 class="text-center mb-4">Silahkan mencoba 😘 🤞</h2>
    </div>
        
</x-layout>