<table border="1">
    <?php
    for($i=1;$i<=4;$i++){
        echo"<tr><td>anjay mabar slebew $i</td></tr>";
    }
    ?>
</table><?php /**PATH C:\xampp\htdocs\laravel_oop\resources\views/coba.blade.php ENDPATH**/ ?>