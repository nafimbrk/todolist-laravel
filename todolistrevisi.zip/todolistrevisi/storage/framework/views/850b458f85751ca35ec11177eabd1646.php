<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equip="X-UA-Compatible" content="IE-adge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/style.css" />
  </head>
  <body>
    <header class="header">
      <a href="#" class="logo" img="coper.jpg">Logo</a>

      <nav class="navbar">
        <a href="cv.php">Home</a>
        <a href="dosen1.blade.php">Dosen</a>
        <a href="mahasiswa1.blade.php">Mahasiswa</a>
      </nav>
    </header>

    <main>
      <section id="hero">
      <img src="coper.jpg" alt="bahrul" width="100">
<table border="1">
  <tr>
    <td align="center">Daftar Nama Dosen</td>
  </tr>
  <tr>
    <td>Moh. Anshori Aris, S.Kom, M.E.</td>
  </tr>
  <tr>
    <td>Dr.H. Nurul Yaqin, M.Sc</td>
  </tr>
  <tr>
    <td>Primaadi Airlangga, M.I.T.</td>
  </tr>
  <tr>
    <td>Sujono, S.Kom</td>
  </tr>
  <tr>
    <td>Dr. Zulfikar, S.P., M.SI.,</td>
  </tr>
  <tr>
    <td>Tholib Hariono, M.Kom</td>
  </tr>
</table>
<a href="mahasiswa.blade.php">Daftar mahasiswa</a>

    </main>
  </body>
</html><?php /**PATH C:\xampp\htdocs\laravel_oop\resources\views/dosen1.blade.php ENDPATH**/ ?>