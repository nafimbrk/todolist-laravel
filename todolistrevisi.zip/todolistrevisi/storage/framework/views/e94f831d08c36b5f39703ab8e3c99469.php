<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mahasiswa</title>
</head>
<body>
<h1>Data Mahasiswa</h1>
<table border="1">
    <thead>
        <tr>
            <th>Id</th>
            <th>Nim</th>
            <th>Nama</th>
            <th>Fakultas</th>
            <th>Prodi</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1</td>
            <td>132436479</td>
            <td>Herman</td>
            <td>Pendidikan</td>
            <td>Bahasa Inggris</td>
        </tr>
        <tr>
            <td>2</td>
            <td>126374856</td>
            <td>Heru</td>
            <td>Teknik</td>
            <td>Elektro</td>
        </tr>
        <tr>
            <td>3</td>
            <td>283651308</td>
            <td>Dono</td>
            <td>Ekonomi</td>
            <td>Manajemen</td>
        </tr>
        <tr>
            <td>4</td>
            <td>152348557</td>
            <td>hendro</td>
            <td>Pertanian</td>
            <td>Agribisnis</td>
        </tr>
        <tr>
            <td>5</td>
            <td>164286057</td>
            <td>Reni</td>
            <td>Teknik</td>
            <td>Informatika</td>
        </tr>
    </tbody>
</table>
<br>
<a href="/dsn">Data Dosen</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel_oop\resources\views/dataMahasiswa.blade.php ENDPATH**/ ?>