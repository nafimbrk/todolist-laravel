<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title', null, []); ?> <?php echo e($title); ?> <?php $__env->endSlot(); ?>
  <table class="table table-hover table-bordered">
<thead class="table-dark">
        <tr>
        <th>Foto</th>
            <th>Nim</th>
            <th>Nama</th>
            <th>Fakultas</th>
            <th>Prodi</th>
            
        </tr>
    </thead>
    <tbody>
        <tr>
        <td><img src="<?php echo e(asset('storage/gambar/herman.jpg')); ?>" alt=""></td>
            <td>132436479</td>
            <td>Herman</td>
            <td>Pendidikan</td>
            <td>Bahasa Inggris</td>
            
        </tr>
        <tr>
        <td><img src="<?php echo e(asset('storage/gambar/heru.jpg')); ?>" alt=""></td>
            <td>126374856</td>
            <td>Heru</td>
            <td>Teknik</td>
            <td>Elektro</td>
            
        </tr>
        <tr>
        <td><img src="<?php echo e(asset('storage/gambar/dono.jpg')); ?>" alt=""></td>
            <td>283651308</td>
            <td>Dono</td>
            <td>Ekonomi</td>
            <td>Manajemen</td>
            
        </tr>
        <tr>
        <td><img src="<?php echo e(asset('storage/gambar/hendro.jpg')); ?>" alt=""></td>
            <td>152348557</td>
            <td>hendro</td>
            <td>Pertanian</td>
            <td>Agribisnis</td>
            
        </tr>
        <tr>
        <td><img src="<?php echo e(asset('storage/gambar/reni.jpg')); ?>" alt=""></td>
            <td>164286057</td>
            <td>Reni</td>
            <td>Teknik</td>
            <td>Informatika</td>
            
        </tr>
    </tbody>
</table>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel_oop\resources\views/daftarMahasiswa.blade.php ENDPATH**/ ?>