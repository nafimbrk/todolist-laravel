<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To Do List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid col-md-7">
            <div class="navbar-brand">Simple To Do List</div>
        </div>
    </nav>

    <div class="container mt-4">
        <h1 class="text-center mb-4">To Do List</h1>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card mb-3">
                    <div class="card-body">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <form id="todo-form" action="<?php echo e(route('todo')); ?>" method="get">
                            <div class="input-group mb-3">
                                <input type="text" class="form-control" name="search" value="<?php echo e(request('search')); ?>"
                                    placeholder="Masukkan kata kunci">
                                <button class="btn btn-secondary" type="submit">
                                    Cari
                                </button>
                            </div>
                        </form>

                        <ul class="list-group mb-4" id="todo-list">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <span class="task-text">
                                        <?php echo $item->is_done == '1' ? '<del>' : ''; ?>

                                        <?php echo e($item->task); ?> - <small><?php echo e($item->due_date->format('d M Y H:i')); ?></small>
                                        <?php echo $item->is_done == '1' ? '</del>' : ''; ?>

                                    </span>
                                    <div class="btn-group">
                                        <form action="<?php echo e(route('todo.delete', ['id' => $item->id])); ?>" method="POST"
                                            onsubmit="return confirm('Yakin akan menghapus data ini?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-danger btn-sm delete-btn">✕</button>
                                        </form>

                                        <button class="btn btn-primary btn-sm edit-btn" data-bs-toggle="collapse"
                                            data-bs-target="#collapse-<?php echo e($loop->index); ?>" aria-expanded="false">✎</button>
                                    </div>
                                </li>
                                <li class="list-group-item collapse" id="collapse-<?php echo e($loop->index); ?>">
                                    <form action="<?php echo e(route('todo.update', ['id' => $item->id])); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('put'); ?>
                                        <div class="input-group mb-3">
                                            <input type="text" class="form-control" name="task" value="<?php echo e($item->task); ?>">
                                            <input type="date" class="form-control" name="due_date" value="<?php echo e($item->due_date->format('Y-m-d')); ?>">
                                            <button class="btn btn-outline-primary" type="submit">Update</button>
                                        </div>
                                        <div class="d-flex">
                                            <div class="radio px-2">
                                                <label>
                                                    <input type="radio" value="1" name="is_done"
                                                        <?php echo e($item->is_done == '1' ? 'checked' : ''); ?>> Selesai
                                                </label>
                                            </div>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" value="0" name="is_done"
                                                        <?php echo e($item->is_done == '0' ? 'checked' : ''); ?>> Belum
                                                </label>
                                            </div>
                                        </div>
                                    </form>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                        <div class="d-flex justify-content-end">
                            <?php echo e($data->links()); ?>

                        </div>

                    </div>
                </div>
                <a href="<?php echo e(route('todo.create')); ?>" class="btn btn-primary">Tambah Task Baru</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap"></script>
<?php /**PATH C:\xampp\htdocs\app-todo-laravel\resources\views/todo/index.blade.php ENDPATH**/ ?>