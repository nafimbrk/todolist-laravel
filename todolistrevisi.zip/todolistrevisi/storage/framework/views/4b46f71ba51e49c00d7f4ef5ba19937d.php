<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equip="X-UA-Compatible" content="IE-adge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/style.css" />
  </head>
  <body>
    <header class="header">
      <a href="#" class="logo" img="coper.jpg">Logo</a>

      <nav class="navbar">
        <a href="cv.php">Home</a>
        <a href="dosen1.blade.php">Dosen</a>
        <a href="mahasiswa1.blade.php">Mahasiswa</a>
      </nav>
    </header>

    <main>
      <section id="hero">
      <img src="coper.jpg" alt="bahrul" width="100">
      <table border="1">
  <tr>
    <td align="center">Daftar Nama Mahasiwa</td>
  </tr>
  <tr>
    <td>Muhamad Bahrul A'lam</td>
  </tr>
  <tr>
    <td>Nanda Pratama W.I</td>
  </tr>
  <tr>
    <td>Rico Nizar Alukman</td>
  </tr>
  <tr>
    <td>Muklis</td>
  </tr>
  <tr>
    <td>Rizki Syam Putra</td>
  </tr>
  <tr>
    <td>M. Ghazi Al Ghifari</td>
  </tr>
</table>

    </main>
  </body>
</html><?php /**PATH C:\xampp\htdocs\laravel_oop\resources\views/mahasiswa1.blade.php ENDPATH**/ ?>