<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <x layout>
        <h3>ini adalah halaman blog</h3>
    </x layout>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel_oop\resources\views/coba2.blade.php ENDPATH**/ ?>