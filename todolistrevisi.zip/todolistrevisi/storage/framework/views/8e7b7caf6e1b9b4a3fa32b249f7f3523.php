<table border="1">
    <?php
    for($i=1;$i<4;$i++){
        echo"<tr><td>nafi jkt 48 ganteng $i</td></tr>";
    }
    ?>
</table>
<?php /**PATH C:\xampp\htdocs\laravel_oop\resources\views/kontak.blade.php ENDPATH**/ ?>