























<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['judul' => 'task priority']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['judul' => 'task priority']); ?>
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="text-end mb-3">
                    <a href="<?php echo e(route('todopry.create')); ?>" class="btn btn-primary text-end">Tambah</a>
                </div>
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                        <table class="table table-bordered border-dark">
                            <thead class="table-dark">
                                <tr>
                                    <th>Minggu</th>
                                    <th>Senin</th>
                                    <th>Selasa</th>
                                    <th>Rabu</th>
                                    <th>Kamis</th>
                                    <th>Jum'at</th>
                                    <th>Sabtu</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $tgl = 1;
                                    $tglakhir = 31;
                                    $hari_pertama = 2; // 1 untuk Senin, 2 untuk Minggu, dll.
                                    $currentDate = \Carbon\Carbon::now()->toDateString();
                                ?>
                                
                                <?php for($week = 0; $week < 6; $week++): ?> <!-- Maksimal 6 minggu dalam sebulan -->
                                    <tr>
                                        <?php for($day = 0; $day < 7; $day++): ?>
                                            <td class="text-truncate">
                                                <?php if($week === 0 && $day < $hari_pertama - 1): ?>
                                                    <!-- Kosongkan sel sampai ke hari pertama -->
                                                    &nbsp;
                                                <?php elseif($tgl <= $tglakhir): ?>
                                                    <b><?php echo e($tgl); ?></b>
                                                    <?php if(isset($tasksPryByDate[$tgl])): ?>
                                                        <div id="carouselExampleControls<?php echo e($tgl); ?>" class="carousel slide" data-bs-ride="carousel">
                                                            <div class="carousel-inner">
                                                                <?php $__currentLoopData = $tasksPryByDate[$tgl]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $taskPry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>">
                                                                        <div class="task-item d-flex justify-content-between <?php echo e($taskPry->due_date < $currentDate ? 'overdue-task' : ''); ?>">
                                                                            <div>
                                                                                <b style="<?php echo e($taskPry->is_done ? 'text-decoration: line-through;' : ''); ?>"><?php echo e(htmlspecialchars($taskPry->task_pry)); ?></b><br>
                                                                                <?php if($taskPry->category): ?>
                                                                                    <small>
                                                                                        <a href="<?php echo e(route('tasks.by.category', ['id' => $taskPry->category->id])); ?>" class="text-decoration-none">
                                                                                            <?php echo e(htmlspecialchars($taskPry->category->name)); ?>

                                                                                        </a>
                                                                                    </small>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                            <div class="btn-group-vertical">
                                                                                <a href="<?php echo e(route('todopry.edit', $taskPry->id)); ?>" class="btn btn-warning btn-sm">Ubah</a>
                                                                                <form action="<?php echo e(route('todopry.delete', $taskPry->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('yakin akan menghapus data ini?')">
                                                                                    <?php echo csrf_field(); ?>
                                                                                    <?php echo method_field('DELETE'); ?>
                                                                                    <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                                                                                </form>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls<?php echo e($tgl); ?>" data-bs-slide="prev">
                                                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                                <span class="visually-hidden">Previous</span>
                                                            </button>
                                                            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls<?php echo e($tgl); ?>" data-bs-slide="next">
                                                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                                <span class="visually-hidden">Next</span>
                                                            </button>
                                                        </div>
                                                    <?php endif; ?>
                                                    <?php $tgl++; ?>
                                                <?php endif; ?>
                                            </td>
                                        <?php endfor; ?>
                                    </tr>
                                    <?php if($tgl > $tglakhir): ?>
                                        <?php break; ?>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </tbody>
                        </table>
                    
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>

<!-- Tambahkan Bootstrap CSS dan JS -->
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

<style>
    .task-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ddd;
        border-radius: 5px;
        max-width: 100%; /* Ensure task-item does not exceed its container */
    }
    .task-item > div:first-child {
        margin-right: 15px;
        flex: 1;
        min-width: 0; /* Ensures flex item respects its container width */
    }
    .btn-group-vertical {
        display: flex;
        flex-direction: column;
        gap: 5px;
    }
    .overdue-task {
        background-color: red;
        color: white;
        padding: 10px;
        border-radius: 5px;
    }
    td {
        max-width: 150px;
        word-wrap: break-word;
    }
    .carousel-inner {
        display: flex;
        align-items: center;
        overflow: hidden;
    }
    .text-truncate {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
</style>






































































































<?php /**PATH C:\xampp\htdocs\todolistrevisi\resources\views/todopry/taskpry.blade.php ENDPATH**/ ?>