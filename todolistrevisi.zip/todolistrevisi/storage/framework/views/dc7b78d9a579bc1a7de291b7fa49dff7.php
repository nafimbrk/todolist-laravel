<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
 <?php $__env->slot('title', null, []); ?> <?php echo e($title); ?> <?php $__env->endSlot(); ?>
<table class="table table-hover table-bordered">
<thead class="table-dark">
        <tr>
        <th>Foto</th>
            <th>Nidn</th>
            <th>Nama</th>
            <th>Fakultas</th>
            <th>Prodi</th>
           
        </tr>
    </thead>
    <tbody>
        <tr>
        <td><img src="<?php echo e(asset('storage/gambar/eko.jpg')); ?>" alt=""></td>
            <td>976589075</td>
            <td>Eko</td>
            <td>Teknik</td>
            <td>Mesin</td>
           
        </tr>
        <tr>
        <td><img src="<?php echo e(asset('storage/gambar/sandika.jpg')); ?>" alt=""></td>
            <td>924648397</td>
            <td>Sandika</td>
            <td>Pertanian</td>
            <td>Agribisnis</td>
            
        </tr>
        <tr>
        <td><img src="<?php echo e(asset('storage/gambar/kurniawan.jpg')); ?>" alt=""></td>
            <td>531784709</td>
            <td>Kurniawan</td>
            <td>Teknik</td>
            <td>Elektro</td>
            
        </tr>
        <tr>
        <td><img src="<?php echo e(asset('storage/gambar/haryanto.jpg')); ?>" alt=""></td>
            <td>41708397</td>
            <td>Haryanto</td>
            <td>Ekonomi</td>
            <td>Manajemen</td>
           
        </tr>
        <tr>
        <td><img src="<?php echo e(asset('storage/gambar/dini.jpg')); ?>" alt=""></td>
            <td>963062709</td>
            <td>Dini</td>
            <td>Teknik</td>
            <td>Informatika</td>
            
        </tr>
    </tbody>
</table>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel_oop\resources\views/daftarDosen.blade.php ENDPATH**/ ?>