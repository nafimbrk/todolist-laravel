<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['judul' => 'Tasks by Category']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['judul' => 'Tasks by Category']); ?>
    <div class="container mt-4">
        <h1 class="text-center mb-4">Tasks by Category</h1>
        <div class="card">
            <div class="card-body">
                <h2 class="card-title mb-3"><?php echo e($category->name); ?></h2>
                <ul class="list-group mb-4" id="todo-list">
                    <?php $__empty_1 = true; $__currentLoopData = $category->todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <div>
                                <span class="task-text">
                                    <?php echo $todo->is_done == '1' ? '<del>' : ''; ?>

                                    <?php echo e($todo->task); ?>

                                    <?php echo $todo->is_done == '1' ? '</del>' : ''; ?>

                                </span>
                                <?php if($todo->due_date): ?>
                                    <span class="badge bg-primary"><?php echo e(\Carbon\Carbon::parse($todo->due_date)->format('d/m/Y')); ?></span>
                                <?php endif; ?>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="list-group-item">
                            Tidak ada task yang cocok dengan category ini
                        </li>
                    <?php endif; ?>
                </ul>
                <a href="<?php echo e(route('todo')); ?>" class="btn btn-secondary">Kembali ke Daftar Task</a>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH /home/u968216815/domains/belajarinformatika.my.id/public_html/todolist/resources/views/todo/tasks_by_category.blade.php ENDPATH**/ ?>