
 
 
 
 
  <?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['judul' => 'task']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['judul' => 'task']); ?>
    <div class="container mt-4">
        <!-- 01. Content -->
        <h1 class="text-center mb-4">Task</h1>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card mb-3">
                    <div class="card-body">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <!-- 02. Form input data -->
                        <form id="todo-form" action="<?php echo e(route('todo.post')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="input-group mb-3">
                                <input type="text" class="form-control" name="task" id="todo-input" placeholder="Tambah task baru" required value="<?php echo e(old('task')); ?>">
                                <input type="text" class="form-control flatpickr" name="due_date" id="due-date-input" placeholder="Tanggal jatuh tempo" value="<?php echo e(old('due_date')); ?>">
                                <select class="form-select" name="category_id">
                                    <option value="" selected>Pilih Kategori</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                
                                <button class="btn btn-primary" type="submit">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <!-- 03. Searching -->
                        <form id="todo-form" action="<?php echo e(route('todo')); ?>" method="get">
                            <div class="input-group mb-3">
                                <input type="text" class="form-control" name="search" value="<?php echo e(request('search')); ?>" placeholder="masukkan kata kunci">
                                <button class="btn btn-secondary" type="submit">Cari</button>
                            </div>
                        </form>

                        <!-- 04. Display Data -->
                        <ul class="list-group mb-4" id="todo-list">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center <?php echo e($item->due_date && $item->due_date < now() ? 'bg-danger text-white' : ''); ?>">
                                <div>
                                    <span class="task-text">
                                        <?php if($item->is_done == '1'): ?>
                                            <del><?php echo e($item->task); ?></del>
                                        <?php else: ?>
                                            <?php echo e($item->task); ?>

                                        <?php endif; ?>
                                    </span>
                                    <?php if($item->due_date): ?>
                                        <span class="badge bg-primary"><?php echo e(\Carbon\Carbon::parse($item->due_date)->format('d/m/Y')); ?></span>
                                    <?php endif; ?>
                                    <?php if($item->category): ?>
                                        <span class="badge bg-secondary">
                                            <a href="<?php echo e(route('tasks.by.category', ['id' => $item->category->id])); ?>" class="text-white text-decoration-none">
                                                <?php echo e($item->category->name); ?>

                                            </a>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="btn-group">
                                    <form action="<?php echo e(route('todo.delete', ['id' => $item->id])); ?>" method="POST" onsubmit="return confirm('yakin akan menghapus data ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button class="btn btn-danger btn-sm delete-btn">✕</button>
                                    </form>
                                    <button class="btn btn-primary btn-sm edit-btn" data-bs-toggle="collapse" data-bs-target="#collapse-<?php echo e($loop->index); ?>" aria-expanded="false">✎</button>
                                </div>
                            </li>
                            <li class="list-group-item collapse" id="collapse-<?php echo e($loop->index); ?>">
                                <form action="<?php echo e(route('todo.update', ['id' => $item->id])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <div>
                                        <div class="input-group mb-3">
                                            <input type="text" class="form-control" name="task" value="<?php echo e($item->task); ?>">
                                            <input type="text" class="form-control flatpickr" name="due_date" value="<?php echo e($item->due_date ? $item->due_date->format('Y-m-d') : ''); ?>">
                                            <select class="form-select" name="category_id">
                                                <option value="" selected>Pilih Kategori</option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>" <?php echo e($item->category_id == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <button class="btn btn-outline-primary" type="submit">Update</button>
                                        </div>
                                    </div>
                                    <div class="d-flex">
                                        <div class="radio px-2">
                                            <label>
                                                <input type="radio" value="0" name="is_done" <?php echo e($item->is_done == '0' ? 'checked' : ''); ?>> Belum
                                            </label>
                                        </div>
                                        <div class="radio">
                                            <label>
                                                <input type="radio" value="1" name="is_done" <?php echo e($item->is_done == '1' ? 'checked' : ''); ?>> Selesai
                                            </label>
                                        </div>
                                    </div>
                                </form>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </ul>
                        <?php echo e($data->withQueryString()->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>




<?php /**PATH /home/u968216815/domains/belajarinformatika.my.id/public_html/todolist/resources/views/todo/task.blade.php ENDPATH**/ ?>