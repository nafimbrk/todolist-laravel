<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dosen</title>
</head>
<body>
<h1>Data Dosen</h1>
<table border="1">
    <thead>
        <tr>
            <th>Id</th>
            <th>Nidn</th>
            <th>Nama</th>
            <th>Fakultas</th>
            <th>Prodi</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1</td>
            <td>976589075</td>
            <td>Eko</td>
            <td>Teknik</td>
            <td>Mesin</td>
        </tr>
        <tr>
            <td>2</td>
            <td>924648397</td>
            <td>Sandika</td>
            <td>Pertanian</td>
            <td>Agribisnis</td>
        </tr>
        <tr>
            <td>3</td>
            <td>531784709</td>
            <td>Kurniawan</td>
            <td>Teknik</td>
            <td>Elektro</td>
        </tr>
        <tr>
            <td>4</td>
            <td>41708397</td>
            <td>Herman</td>
            <td>Ekonomi</td>
            <td>Manajemen</td>
        </tr>
        <tr>
            <td>5</td>
            <td>963062709</td>
            <td>Dini</td>
            <td>Teknik</td>
            <td>Informatika</td>
        </tr>
    </tbody>
</table>
<br>
<a href="/mhs">Data Mahasiswa</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel_oop\resources\views/dataDosen.blade.php ENDPATH**/ ?>